// error.c
#include <stdio.h>

int main(){


    int x = 8;
    if(7==x){
        printf("Yes, x is 7!\n");
    }


    return 0;
}
