// reverse.c

int square(int x){
    return x*x;
}


int main(){

    int i = 0;
    int result = square(i);
    
    return i;
}
