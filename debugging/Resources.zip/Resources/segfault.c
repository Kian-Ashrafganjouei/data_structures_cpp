// segfault.c
#include <stdio.h>
int main(){


    int* px = NULL;

    printf("px value is %d",*px);

//    int array[10];
//    array[100000000] = 7;

    return 0;
}
